# summary
- title:compiler system hw1
- author:丁國騰
- student id:E94036209
- class:資訊系三乙

# Usage

- in your shell command line:

- lex:

```
$ flex Compiler_E94036209_HW1.l
```

- compile with gcc:

```
$ gcc lex.yy.c -lfl -o output -g3
```

- execute:

```
$ ./output [your file]
```


